package com;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Orders {
	
	@Id
	private int orderId;
	private LocalDateTime orderDate;
		
	public Orders() {
		
	}
	
	public Orders(int orderId, LocalDateTime orderDate) {
		this.orderId = orderId;
		this.orderDate = orderDate;
	}
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name="order_details",
			   joinColumns = {@JoinColumn(name="orderid")},
			   inverseJoinColumns = {@JoinColumn(name="itemid")})
	private List<Items> items=new ArrayList<Items>();
	
	public List<Items> getItems() {
		return items;
	}

	public void setItems(List<Items> items) {
		this.items = items;
	}

	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public LocalDateTime getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(LocalDateTime orderDate) {
		this.orderDate = orderDate;
	}
	
	

}

