package com;

import java.time.LocalDateTime;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cts.product.config.DBConfig;

public class Test {
	
    public static void main(String[] args) {
    	
    	SessionFactory sessionfactory=DBConfig.getSessionbFactory();		
		
		Session session=sessionfactory.openSession();
	
		Customer cust1=new Customer(1000, "Praveen");
		Customer cust2=new Customer(1001, "Ozvitha");
		
		Orders ord1=new Orders(10000,LocalDateTime.now());
		Orders ord2=new Orders(10001,LocalDateTime.now());
		
		Items itm1=new Items(1, "Soap", 34);
		Items itm2=new Items(2, "Book", 45);
		Items itm3=new Items(3, "Mouse", 1500);
		Items itm4=new Items(4, "Mobile", 25000);
		Items itm5=new Items(5, "Laptop", 45000);
		Items itm6=new Items(6, "IPad", 53500);
		
		ord1.getItems().add(itm1);
		ord1.getItems().add(itm2);
		ord1.getItems().add(itm3);
		
		ord2.getItems().add(itm4);
		ord2.getItems().add(itm5);
		ord2.getItems().add(itm6);
		
		cust1.getOrders().add(ord1);
		cust2.getOrders().add(ord2);
		
		Billing bill1=new Billing(500, LocalDateTime.now(), 1579);
		Billing bill2=new Billing(501, LocalDateTime.now(), 123500);
		
		bill1.setCust(cust1);
		bill1.setOrder(ord1);
		
		bill2.setCust(cust1);
		bill2.setOrder(ord2);
		
		session.save(cust1);
		session.save(cust2);
		session.save(bill1);
		session.save(bill2);

		session.beginTransaction().commit();
		
	}
}