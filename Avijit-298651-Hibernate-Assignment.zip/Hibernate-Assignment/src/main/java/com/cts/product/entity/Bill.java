package com.cts.product.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.mysql.cj.x.protobuf.MysqlxCrud.Order;

@Entity
public class Bill {
	
	@Id
	private int billID;
	private LocalDateTime billDate;
	private double totalBill;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="custid")
	private Customer customer;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="orderid")
	private Orders order;
	
	public Bill() {
		
	}
	
	public Bill(int billID, LocalDateTime billDate, double totalBill) {
		super();
		this.billID = billID;
		this.billDate = billDate;
		this.totalBill = totalBill;
	}
	
	
	
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Orders getOrder() {
		return order;
	}

	public void setOrder(Orders order) {
		this.order = order;
	}

	public int getBillID() {
		return billID;
	}
	public void setBillID(int billID) {
		this.billID = billID;
	}
	public LocalDateTime getBillDate() {
		return billDate;
	}
	public void setBillDate(LocalDateTime billDate) {
		this.billDate = billDate;
	}
	public double getTotalBill() {
		return totalBill;
	}
	public void setTotalBill(double totalBill) {
		this.totalBill = totalBill;
	}
	
	

}
