package com;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.cts.product.config.DBConfig;
import com.cts.product.entity.Bill;
import com.cts.product.entity.Customer;
import com.cts.product.entity.Items;
import com.cts.product.entity.Orders;

public class PrintOutput {

	public static void main(String[] args) {
		Session ses = DBConfig.getSessionbFactory().openSession();
		
		Customer cust=ses.get(Customer.class,1000);
		System.out.println("cust ID: "+ cust.getCustId() );
		System.out.println("cust Name: "+ cust.getCustName() );
		
		List<Orders> lstorder=cust.getOrders();
		
		for (Orders ord:lstorder) {
			System.out.println("Order ID: "+ ord.getOrderId());
			System.out.println("Order Date: "+ ord.getOrderDate());
			
			List<Items> items=ord.getItems();
			
			System.out.println("---------------------------------------------------");
			System.out.println("Item Id" + "\t" + "Item Name" + "\t" + "Price");
			System.out.println("---------------------------------------------------");
			
			for (Items itms:items) {
				System.out.print(itms.getItemID() + "\t" + itms.getItemName() + "\t\t" + itms.getPrice());
				System.out.println();			
			}	
			
			System.out.println("---------------------------------------------------");
							
		}
		
		Bill bl=ses.get(Bill.class, 500);
		System.out.println("Bill ID: "+bl.getBillID());
		System.out.println("Customer ID: "+bl.getCustomer().getCustId());
		System.out.println("Order ID: "+bl.getOrder().getOrderId());
		System.out.println("Bill Date: "+bl.getBillDate());
		System.out.println("Bill Amount: "+bl.getTotalBill());
		
		
		System.out.println("---------------------------------------------------");	

	}

}
