package com;


import java.time.LocalDateTime;

import org.hibernate.Session;
import com.cts.product.config.DBConfig;
import com.cts.product.entity.Bill;
import com.cts.product.entity.Customer;
import com.cts.product.entity.Items;
import com.cts.product.entity.Orders;


public class Test {

	public static void main(String[] args){

		Session ses = DBConfig.getSessionbFactory().openSession();
		
		Customer cust1=new Customer(1000,"Praveen");
		Customer cust2=new Customer(1001,"Ozvitha");

		Items itm1=new Items(1,"Soap",34);
		Items itm2=new Items(2,"Book",45);
		Items itm3=new Items(3,"Mouse",1500);
		Items itm4=new Items(4,"Mobile",25000);
		Items itm5=new Items(5,"Laptop",45000);
		Items itm6=new Items(6,"IPad",53500);
		
		LocalDateTime ld=LocalDateTime.now();
		Orders ord1=new Orders(10000,ld);
		Orders ord2=new Orders(10001,LocalDateTime.of(2019, 12, 05, 11, 00));
		
		Bill bil1=new Bill(500,ld,1579);
		Bill bil2=new Bill(501,ld,123500);
		
		/*itm1.getOrders().add(ord1);
		itm2.getOrders().add(ord1);
		itm3.getOrders().add(ord1);
		itm4.getOrders().add(ord2);
		itm5.getOrders().add(ord2);
		itm6.getOrders().add(ord2);*/
		
		ord1.getItems().add(itm1);
		ord1.getItems().add(itm2);
		ord1.getItems().add(itm3);
		
		ord2.getItems().add(itm4);
		ord2.getItems().add(itm5);
		ord2.getItems().add(itm6);
		
		//ses.save(ord1);
		//ses.save(ord2);
		
		bil1.setCustomer(cust1);
		bil2.setCustomer(cust2);
		bil1.setOrder(ord1);
		bil2.setOrder(ord2);
		
		cust1.getOrders().add(ord1);
		cust2.getOrders().add(ord2);
		
		ses.save(bil1);
		ses.save(bil2);
		ses.save(cust1);
		ses.save(cust2);
	/*	ses.save(itm1);
		ses.save(itm2);
		ses.save(itm3);
		ses.save(itm4);
		ses.save(itm5);
		ses.save(itm6); */
		
		
		ses.beginTransaction().commit();
		System.out.println("--- Done");

	}

}
