package com;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.db.config.DBConfig;
import com.supermarket.entity.Billing;
import com.supermarket.entity.Customer;
import com.supermarket.entity.Items;
import com.supermarket.entity.Orders;


public class InsertCustomerOrderItemsData {

	public static void main(String[] args) throws HibernateException, IOException{
			
			Session ses =DBConfig.getSessionbFactory().openSession();
			
			Orders ord1 = new Orders(10000, LocalDateTime.now());
			Orders ord2 = new Orders(10001, LocalDateTime.now());
			
			Customer cust1 = new Customer(1000, "Praveen");
			Customer cust2 = new Customer(1001, "Ozvitha");
			
			Items item1 = new Items(1, "Soap", 34);
			Items item2 = new Items(2, "Book", 45);
			Items item3 = new Items(3, "Mouse", 1500);
			Items item4 = new Items(4, "Mobile", 25000);
			Items item5 = new Items(5, "Laptop", 45000);
			Items item6 = new Items(6, "Ipad", 53500);
						
			cust1.getOrder().add(ord1);
			cust2.getOrder().add(ord2);
			
			ses.save(cust1);
			ses.save(cust2);
			
			ord1.getItems().add(item1);
			ord1.getItems().add(item2);
			ord1.getItems().add(item3);
			ord2.getItems().add(item4);
			ord2.getItems().add(item5);
			ord2.getItems().add(item6);
			

			ses.save(ord1);
			ses.save(ord2);
			
			//-------------------------------------------------------------------------------------
		    double billAmt = 0;
		    Customer customer1=ses.get(Customer.class,1000); 
		    List<Orders>lstorder=customer1.getOrder();
		    for (Orders ord:lstorder) { 
		    	List<Items> items=ord.getItems(); 
		    	for (Items itms:items) { 
		    		billAmt = billAmt + itms.getPrice(); 
		    		} 
		    	}
			//-------------------------------------------------------------------------------------
			Billing bill1=new Billing(500, LocalDateTime.now(), billAmt);
			//-------------------------------------------------------------------------------------
			
			billAmt = 0;
		 
			Customer customer2=ses.get(Customer.class,1001); 
			List<Orders>secorder=customer2.getOrder();
			for (Orders ord:secorder) { 
				List<Items> items=ord.getItems(); 
				for (Items itms:items) { 
					billAmt = billAmt + itms.getPrice(); 
					} 
				}
			//-------------------------------------------------------------------------------------
			Billing bill2=new Billing(501, LocalDateTime.now(), billAmt);
			
			bill1.setCustomer(cust1);
			bill1.setOrders(ord1);
			
			bill2.setCustomer(cust2);
			bill2.setOrders(ord2);
			
			ses.save(bill1);
			ses.save(bill2);
			
			
			ses.beginTransaction().commit();
		}
	
}
