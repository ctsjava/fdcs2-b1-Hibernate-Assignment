package com;

import java.io.IOException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.db.config.DBConfig;
import com.supermarket.entity.Customer;
import com.supermarket.entity.Items;
import com.supermarket.entity.Orders;


public class FetchCustomerBill {
	
	public static void main(String[] args) throws IOException {
		
		SessionFactory sessfac=DBConfig.getSessionbFactory();
		Session sess=sessfac.openSession();
		
		Customer cust=sess.get(Customer.class,1000);
		
		System.out.println("cust ID: "+ cust.getCustID() );
		System.out.println("cust Name: "+ cust.getCustName() );
		
		List<Orders> lstorder=cust.getOrder();
		
		for (Orders ord:lstorder) {
			System.out.println("Order ID: "+ ord.getOrderId());
			System.out.println("Order Date: "+ ord.getOrderDate());
			
			List<Items> items=ord.getItems();
			
			System.out.println("---------------------------------------------------");
			System.out.println("Item Id" + "\t" + "Item Name" + "\t" + "Price");
			System.out.println("---------------------------------------------------");
		
			for (Items itms:items) {
				System.out.print(itms.getItemId() + "\t" + itms.getItemName() + "\t" + itms.getPrice());
				System.out.println();			
			}	
			
			
			System.out.println("------------------------------------------------------------------------");
			
			@SuppressWarnings("unchecked")
			Query<Object[]> qry=sess.getNamedNativeQuery("findbillidbyorderid").setParameter("order_id", ord.getOrderId());
			List<Object[]> lst=qry.list();					
			
			System.out.println("------------------------------------------------------------------------");
			
			for (Object[] obj:lst) {
				  
				for (int i=0;i<obj.length;i++) {
				      switch (i) {
				      case 0:
				    	  System.out.println("Bill Id: " + obj[i]);
				    	  break;
				      case 1:
				    	  System.out.println("Cust Id: " + obj[i]);
				    	  break;
				      case 2:
				    	  System.out.println("Order Id: " + obj[i]);
				    	  break;
				      case 3:
				    	  System.out.println("Bill Date: " + obj[i]);
				    	  break;
				      case 4:
				    	  System.out.println("Total Bill Amount: " + obj[i]);
				    	  break;
				      }
				    	 
				}
			}					
		}
		
		System.out.println("---------------------------------------------------");	
		
		
	}

}

