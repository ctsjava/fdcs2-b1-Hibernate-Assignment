package com.db.config;

import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Environment;

import com.supermarket.entity.Billing;
import com.supermarket.entity.Customer;
import com.supermarket.entity.Items;
import com.supermarket.entity.Orders;

public class DBConfig {

	private static StandardServiceRegistry registry;
	private static SessionFactory sessionFactory;

	public static SessionFactory getSessionbFactory() throws IOException {

		StandardServiceRegistryBuilder registryBuilder = new StandardServiceRegistryBuilder();
		
		Properties props = new Properties();
		props.load(ClassLoader.getSystemClassLoader().getResourceAsStream("db.properties"));

		HashMap<String, String> settings = new HashMap<String, String>();
		settings.put(Environment.DRIVER, props.getProperty("mysql.driver"));
		settings.put(Environment.URL, props.getProperty("mysql.url"));
		settings.put(Environment.USER, props.getProperty("mysql.user"));
		settings.put(Environment.PASS, props.getProperty("mysql.password"));
		settings.put(Environment.DIALECT, props.getProperty("mysql.dialect"));
		settings.put(Environment.SHOW_SQL, props.getProperty("show.sql"));
		settings.put(Environment.HBM2DDL_AUTO, props.getProperty("hbm.ddl.auto"));
		settings.put(Environment.FORMAT_SQL, props.getProperty("format.sql"));

		registryBuilder.applySettings(settings);

		registry = registryBuilder.build();

		MetadataSources metadataSources = new MetadataSources(registry);
		metadataSources.addAnnotatedClass(Customer.class);
		metadataSources.addAnnotatedClass(Orders.class);
		metadataSources.addAnnotatedClass(Items.class);
		metadataSources.addAnnotatedClass(Billing.class);

		Metadata metadata = metadataSources.getMetadataBuilder().build();

		sessionFactory = metadata.buildSessionFactory();

		return sessionFactory;
	}

}
