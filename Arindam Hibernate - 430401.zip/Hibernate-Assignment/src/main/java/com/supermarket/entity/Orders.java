package com.supermarket.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;


@Entity
public class Orders {
	@Id
	private int orderId;
	private LocalDateTime orderDate;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "ORDER_DETAILS", joinColumns = { @JoinColumn(name = "order_id") }, inverseJoinColumns = {@JoinColumn(name = "item_id") })
	private List<Items> items = new ArrayList<Items>();
	
	
	public Orders() {
		
	}

	public Orders(int orderId, LocalDateTime orderDate) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public LocalDateTime getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDateTime orderDate) {
		this.orderDate = orderDate;
	}

	public List<Items> getItems() {
		return items;
	}

	public void setItems(List<Items> items) {
		this.items = items;
	}

	

}
