package com.supermarket.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

@Entity(name="Customer")

public class Customer {
	@Id
	private int custID;
	private String custName;

	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinTable(name="CUSTOMER_ORDER",joinColumns = {@JoinColumn(name = "cust_id")}, inverseJoinColumns = {@JoinColumn(name = "order_id")})
	List<Orders> order = new ArrayList<Orders>();
	
	public Customer() {
		
	}


	public Customer(int custID, String custName) {
		super();
		this.custID = custID;
		this.custName = custName;
	}


	public int getCustID() {
		return custID;
	}


	public void setCustID(int custID) {
		this.custID = custID;
	}


	public String getCustName() {
		return custName;
	}


	public void setCustName(String custName) {
		this.custName = custName;
	}


	public List<Orders> getOrder() {
		return order;
	}


	public void setOrder(List<Orders> order) {
		this.order = order;
	}
	
	
	
}
