package com.supermarket.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Items {
	@Id
	private int itemId;
	private String itemName;
	private double price;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "ORDER_DETAILS", joinColumns = { @JoinColumn(name = "item_id") }, inverseJoinColumns = {@JoinColumn(name = "order_id") })
	private List<Orders> orders = new ArrayList<Orders>();
	
	public Items() {
		
	}

	public Items(int itemId, String itemName, double price) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.price = price;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	

}
