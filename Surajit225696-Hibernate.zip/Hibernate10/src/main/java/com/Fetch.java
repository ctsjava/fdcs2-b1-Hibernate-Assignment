package com;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.cts.ozvitha.config.DBConfig;
import com.cts.ozvitha.entity.Customer;
import com.cts.ozvitha.entity.Items;
import com.cts.ozvitha.entity.Orders;


public class Fetch {

	public static void main(String[] args) {
		
		SessionFactory sessfac=DBConfig.getSessionbFactory();
		Session sess=sessfac.openSession();
		
		Customer cust=sess.get(Customer.class,1000);
		System.out.println("Cust ID: "+ cust.getCustId() );
		System.out.println("Cust Name: "+ cust.getCustName() );
		
		List<Orders> lstorder = cust.getOrd();
		
		for (Orders ord:lstorder) {
			System.out.println("Order ID: "+ ord.getOrderId());
			System.out.println("Order Date: "+ ord.getOrderDate());
			
			List<Items> items=ord.getItms();
			
			System.out.println("---------------------------------------------------");
			System.out.println("Item Id" + "\t" + "Item Name" + "\t" + "Price");
			System.out.println("---------------------------------------------------");
			
			for (Items itms:items) {
				System.out.print(itms.getItemId() + "\t" + itms.getItemName() + "\t" + itms.getItemPrice());
				System.out.println();			
			}
			
			System.out.println("---------------------------------------------------------");
			
			@SuppressWarnings("unchecked")
			Query<Object[]> qry=sess.getNamedNativeQuery("querybill").setParameter("order_id", ord.getOrderId());
			List<Object[]> lst=qry.list();					
			
			for (Object[] obj:lst) {
				  
				for (int i=0;i<obj.length;i++) {
				      switch (i) {
				      case 0:
				    	  System.out.println("Bill Id: " + obj[i]);
				    	  break;
				      case 1:
				    	  System.out.println("Cust Id: " + obj[i]);
				    	  break;
				      case 2:
				    	  System.out.println("Order Id: " + obj[i]);
				    	  break;
				      case 3:
				    	  System.out.println("Bill Date: " + obj[i]);
				    	  break;
				      case 4:
				    	  System.out.println("Total Bill Amount: " + obj[i]);
				    	  break;
				      }
				    	 
				}
			}					
			
			System.out.println();
		}
		
		
		System.out.println("---------------------------------------------------");
			
		}	
		
		
		
		

	}


