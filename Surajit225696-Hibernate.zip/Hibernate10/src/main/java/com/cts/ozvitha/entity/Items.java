package com.cts.ozvitha.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Items {
	@Id
	private int itemId;
	private String itemName;
	private int itemPrice;
	
	public Items() {
		
	}

	public Items(int itemId, String itemName, int itemPrice) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
	}
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "Order_Details", joinColumns = { @JoinColumn(name = "itemId") }, inverseJoinColumns = {
			@JoinColumn(name = "orderId") })
	private List<Orders> ords = new ArrayList<Orders>();

	public List<Orders> getOrds() {
		return ords;
	}

	public void setOrds(List<Orders> ords) {
		this.ords = ords;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}
	
	
}
