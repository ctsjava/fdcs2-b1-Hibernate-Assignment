package com.cts.ozvitha.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;


@Entity
public class Customer {

	@Id
	private int custId;
	private String custName;
	
	public Customer() {
		
	}
	
	public Customer(int custId, String custName) {
		super();
		this.custId = custId;
		this.custName = custName;
	}
	
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinTable(name = "Customer_Orders", 
	joinColumns = { @JoinColumn(name = "custId") }, 
	inverseJoinColumns = {@JoinColumn(name = "orderId") })
	List<Orders> ord = new ArrayList<Orders>();

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public List<Orders> getOrd() {
		return ord;
	}

	public void setOrd(List<Orders> ord) {
		this.ord = ord;
	}


	
	
	
}
