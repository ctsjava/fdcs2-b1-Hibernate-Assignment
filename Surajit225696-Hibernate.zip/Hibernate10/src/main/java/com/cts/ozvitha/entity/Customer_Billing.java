package com.cts.ozvitha.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedNativeQuery;
import javax.persistence.OneToOne;


@Entity
@NamedNativeQuery(name="querybill",query="select t.billId,t.custId,t.orderId,t.billDate,t.totalBill from Customer_Billing t where t.orderId=:order_id")
public class Customer_Billing {
	
	@Id
	private int billId;
	private LocalDateTime billDate;
	private int totalBill;
	
	public Customer_Billing() {
		// TODO Auto-generated constructor stub
	}
	
	public Customer_Billing(int billId, LocalDateTime billDate, int totalBill) {
		super();
		this.billId = billId;
		this.billDate = billDate;
		this.totalBill = totalBill;
	}
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="custid")
	private Customer cust;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="orderid")
	private Orders order;

	public int getBillId() {
		return billId;
	}

	public void setBillId(int billId) {
		this.billId = billId;
	}

	public LocalDateTime getBillDate() {
		return billDate;
	}

	public void setBillDate(LocalDateTime billDate) {
		this.billDate = billDate;
	}

	public int getTotalBill() {
		return totalBill;
	}

	public void setTotalBill(int totalBill) {
		this.totalBill = totalBill;
	}

	public Customer getCust() {
		return cust;
	}

	public void setCust(Customer cust) {
		this.cust = cust;
	}

	public Orders getOrder() {
		return order;
	}

	public void setOrder(Orders order) {
		this.order = order;
	}
	
	
	
	
	



	

	
	

}
