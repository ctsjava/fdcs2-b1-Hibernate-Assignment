package com.cts.ozvitha.entity;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;


@Entity
public class Orders {

	@Id
	//@Basic(fetch = FetchType.EAGER)
	private int orderId;
	private LocalDateTime orderDate;
	
	public Orders() {
		// TODO Auto-generated constructor stub
	}

	public Orders(int orderId, LocalDateTime orderDate) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
	}
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "Order_Details", joinColumns = { @JoinColumn(name = "orderId") }, inverseJoinColumns = {
			@JoinColumn(name = "itemId") })
	private List<Items> itms = new ArrayList<Items>();

	
	public List<Items> getItms() {
		return itms;
	}

	public void setItms(List<Items> itms) {
		this.itms = itms;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public LocalDateTime getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDateTime orderDate) {
		this.orderDate = orderDate;
	}

	
}
