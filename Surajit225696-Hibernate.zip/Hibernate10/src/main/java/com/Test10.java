package com;

import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.Session;

import com.cts.ozvitha.config.DBConfig;
import com.cts.ozvitha.entity.Orders;
import com.cts.ozvitha.entity.Customer;
import com.cts.ozvitha.entity.Customer_Billing;
import com.cts.ozvitha.entity.Items;

public class Test10 {

	public static void main(String[] args) {

		Session ses = DBConfig.getSessionbFactory().openSession();

		Customer c1 = new Customer(1000, "Praveen");
		Customer c2 = new Customer(1001, "Ozvitha");
		
		Orders o1 = new Orders(10000, LocalDateTime.now());
		Orders o2 = new Orders(10001, LocalDateTime.now());
		
		Items i1 = new Items(1, "Soap", 34);
		Items i2 = new Items(2, "Book", 45);
		Items i3 = new Items(3, "Mouse", 1500);
		Items i4 = new Items(4, "Mobile", 25000);
		Items i5 = new Items(5, "Laptop", 45000);
		Items i6 = new Items(6, "IPad", 53500);
		
		c1.getOrd().add(o1);
		c2.getOrd().add(o2);

		ses.save(c1);
		ses.save(c2);
		
		o1.getItms().add(i1);
		o1.getItms().add(i2);
		o1.getItms().add(i3);
		o2.getItms().add(i4);
		o2.getItms().add(i5);
		o2.getItms().add(i6);
		
		ses.save(o1);
		ses.save(o2);
		
		int billAmt = 0;
		
		Customer custo1=ses.get(Customer.class,1000);
		List<Orders> lstorder=custo1.getOrd();

		for (Orders ord:lstorder) {
			List<Items> items=ord.getItms();
			for (Items itms:items) {
				billAmt = billAmt + itms.getItemPrice();			
			}
		}	
		
		Customer_Billing cb1 = new Customer_Billing(500, LocalDateTime.now(), billAmt);
		
	
		int billAmt2 = 0;
		
		Customer custo2=ses.get(Customer.class,1001);
		List<Orders> lstorder2=custo2.getOrd();

		for (Orders ord:lstorder2) {
			List<Items> items=ord.getItms();
			for (Items itms:items) {
				billAmt2 = billAmt2 + itms.getItemPrice();			
			}
		}	
		
		Customer_Billing cb2 = new Customer_Billing(501, LocalDateTime.now(), billAmt2); 
		
		cb1.setCust(c1);
		cb1.setOrder(o1);
		cb2.setCust(c2);
		cb2.setOrder(o2);
		
		ses.save(cb1);
		ses.save(cb2);
		
		ses.beginTransaction().commit();

	}

}
