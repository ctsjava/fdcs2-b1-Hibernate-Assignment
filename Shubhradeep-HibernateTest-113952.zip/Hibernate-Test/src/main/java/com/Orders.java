package com;

 

import java.time.LocalDateTime;

import java.util.ArrayList;

import java.util.List;

 

import javax.persistence.CascadeType;

import javax.persistence.Entity;

import javax.persistence.FetchType;

import javax.persistence.Id;

import javax.persistence.JoinColumn;

import javax.persistence.JoinTable;

import javax.persistence.ManyToMany;

 

@Entity

public class Orders {

      

          @Id

       private int orderId;

       private LocalDateTime localdttm;

      

       @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)

          @JoinTable(name = "Order_Details", joinColumns = { @JoinColumn(name = "orderId") },

          inverseJoinColumns = {@JoinColumn(name = "ItemId") })

      

          private List<Items> items = new ArrayList<Items>();

      

       

    public Orders() {

      

    }

   

    

       

    public Orders(int orderId, LocalDateTime localdttm) {

              super();

              this.orderId = orderId;

              this.localdttm = localdttm;

             

       }

 

 

 

       public List<Items> getItems() {

              return items;

       }

       public void setItems(List<Items> items) {

              this.items = items;

       }

       public int getOrderId() {

              return orderId;

       }

       public void setOrderId(int orderId) {

              this.orderId = orderId;

       }

       public LocalDateTime getLocaldttm() {

              return localdttm;

       }

       public void setLocaldttm(LocalDateTime localdttm) {

              this.localdttm = localdttm;

       }

      

       

 

}

 

 