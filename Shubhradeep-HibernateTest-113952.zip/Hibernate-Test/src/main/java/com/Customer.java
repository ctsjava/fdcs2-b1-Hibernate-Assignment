package com;

 

import java.util.ArrayList;

import java.util.List;

 

import javax.persistence.CascadeType;

import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.JoinColumn;

import javax.persistence.JoinTable;

import javax.persistence.OneToMany;

 

@Entity

public class Customer {

      

       @Id

       private int CustId;

       private String CustName;

      

       @OneToMany(cascade=CascadeType.ALL)

       @JoinTable(name="Customer_orders",

       joinColumns= {@JoinColumn(name="CustId")},

       inverseJoinColumns= {@JoinColumn(name="orderid")})

      

       private List<Orders> orders=new ArrayList<Orders>();

      

       public Customer() {

             

       }

      

      

       

       

    public Customer(int custId, String custName) {

              super();

              CustId = custId;

              CustName = custName;

             

       }

 

 

 

 

       public List<Orders> getOrders() {

              return orders;

       }

       public void setOrders(List<Orders> orders) {

              this.orders = orders;

       }

       public int getCustId() {

              return CustId;

       }

       public void setCustId(int custId) {

              CustId = custId;

       }

       public String getCustName() {

              return CustName;

       }

       public void setCustName(String custName) {

              CustName = custName;

       }

      

       

 

}

 