package com;

 

import java.time.LocalDateTime;

 

import javax.persistence.CascadeType;

import javax.persistence.Entity;

import javax.persistence.FetchType;

import javax.persistence.Id;

import javax.persistence.JoinColumn;
import javax.persistence.NamedNativeQuery;
import javax.persistence.OneToOne;

 

@Entity
@NamedNativeQuery(name="findbill",
query="select bl.billId,bl.custid,bl.orderid,bl.billtime,bl.totalbill from billing bl where bl.orderid=:orderid")
public class Billing {

      

       @Id

       private int billId;

       private LocalDateTime billtime;

       private double totalbill;

      

      

       @OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)

       @JoinColumn(name = "orderid")

       private Orders orders;

      

       @OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)

       @JoinColumn(name = "CustId")

       private Customer customer;

      

       public Billing() {

             

       }

      

      

      

      

       public Billing(int billId, LocalDateTime billtime, double totalbill) {

              super();

              this.billId = billId;

              this.billtime = billtime;

              this.totalbill = totalbill;

       }

 

 

 

 

       public Orders getOrders() {

              return orders;

       }

       public void setOrders(Orders orders) {

              this.orders = orders;

       }

       public Customer getCustomer() {

              return customer;

       }

       public void setCustomer(Customer customer) {

              this.customer = customer;

       }

       public int getBillId() {

              return billId;

       }

       public void setBillId(int billId) {

              this.billId = billId;

       }

       public LocalDateTime getBilltime() {

              return billtime;

       }

       public void setBilltime(LocalDateTime billtime) {

              this.billtime = billtime;

       }

       public double getTotalbill() {

              return totalbill;

       }

       public void setTotalbill(double totalbill) {

              this.totalbill = totalbill;

       }

      

      

 

}

 