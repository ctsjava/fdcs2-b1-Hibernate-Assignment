package com;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

public class FetchCust {

       public static void main(String[] args) {

              Session ses = DBConfig.getSessionbFactory().openSession();

             

              Customer c1=ses.get(Customer.class, 1000);

             

              System.out.println("Customer Id: "+c1.getCustId());

              System.out.println("Customer Name: "+c1.getCustName());

             

              //System.out.println("Order id: "+c1.getOrders().);

             

              for(Orders or:c1.getOrders()) {

                     System.out.println("Order Id: "+or.getOrderId());

                     System.out.println("Order Time: "+or.getLocaldttm());
                     //System.out.println();
                     
                	 System.out.println("------------------------------------");
                	 System.out.println("ItemId	"+"ItemName	"+"Price");
                	 System.out.println("------------------------------------");

                     for(Items i:or.getItems()) {
                    	 


                           System.out.println(i.getItemId()+"	"+i.getItemName()+"		"+i.getPrice());

                           //System.out.println(i.getItemName());

                           //System.out.println(i.getPrice());

                           //System.out.println("-----------------------------");

                     }

                     System.out.println("------------------------------------");
                     
         			@SuppressWarnings("unchecked")
        			Query<Object[]> qry=ses.getNamedNativeQuery("findbill").setParameter("orderid",or.getOrderId());
        			List<Object[]> list=qry.list();					
        			
        			//System.out.println("------------------------------------------------------------------------");
        			
        			for (Object[] obj:list) {
        				  
        				for (int i=0;i<obj.length;i++) {
        				      switch (i) {
        				      case 0:
        				    	  System.out.println("Bill Id: " + obj[i]);
        				    	  break;
        				      case 1:
        				    	  System.out.println("Cust Id: " + obj[i]);
        				    	  break;
        				      case 2:
        				    	  System.out.println("Order Id: " + obj[i]);
        				    	  break;
        				      case 3:
        				    	  System.out.println("Bill Date: " + obj[i]);
        				    	  break;
        				      case 4:
        				    	  System.out.println("Total Bill Amount: " + obj[i]);
        				    	  break;
        				      }

              }
              
            	  
              }

 

       }
       }
}

 



 

 

 