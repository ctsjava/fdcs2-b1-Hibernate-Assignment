package com;

 

import java.time.LocalDateTime;

import org.hibernate.Session;

 

 

 

public class Test {

 

       public static void main(String[] args) {

 

              Session ses = DBConfig.getSessionbFactory().openSession();

             
              Customer c1=new Customer(1000, "Praveen");
              Customer c2=new Customer(1001, "Ozvitha");

              Orders o1=new Orders(10000, LocalDateTime.now());
              Orders o2=new Orders(10001, LocalDateTime.now());


              Items i1=new Items(1, "Soap", 34);
              Items i2=new Items(2, "Book", 45);
              Items i3=new Items(3, "Mouse", 1500);
              Items i4=new Items(4, "Mobile", 25000);
              Items i5=new Items(5, "Laptop", 45000);
              Items i6=new Items(6, "Ipad", 53500);

              o1.getItems().add(i1);
              o1.getItems().add(i2);
              o1.getItems().add(i3);

              o2.getItems().add(i4);
              o2.getItems().add(i5);
              o2.getItems().add(i6);
            

              c1.getOrders().add(o1);
              c2.getOrders().add(o2);


              ses.save(o1);
              ses.save(o2);

              ses.save(c1);
              ses.save(c2);
              
              double totalbill=0;
              for(Orders or1:c1.getOrders()) {
            	  for(Items it1:or1.getItems()) {
            		  totalbill=totalbill+it1.getPrice();
            	  }
            	  
              }
              
              Billing b1=new Billing(500, LocalDateTime.now(), totalbill);
              totalbill=0;
              for(Orders or2:c2.getOrders()) {
            	  for(Items it2:or2.getItems()) {
            		  totalbill=totalbill+it2.getPrice();
            	  }
            	  
              }      
              
              Billing b2=new Billing(501, LocalDateTime.now(), totalbill);
              
              b1.setCustomer(c1);
              b1.setOrders(o1);
              
              b2.setCustomer(c2);
              b2.setOrders(o2);
              
              ses.save(b1);
              ses.save(b2);

             
              ses.beginTransaction().commit();

              

             

             

      

             

          /*      Customer c1 = ses.get(Customer.class, 1000);

                Customer c2 =ses.get(Customer.class, 1001);

               

               

                

                

                Orders o1=ses.get(Orders.class, 10000);

                Orders o2=ses.get(Orders.class,10001);

               

                Customer c3=new Customer(1003, "Shub");

                Orders o3=new Orders(10003, LocalDateTime.now());

               

                Items i1=new Items(1, "Pen", 10);

                Items i2=new Items(2, "Book", 14);

               

                o3.getItems().add(i1);

                o3.getItems().add(i2);

               

                c3.getOrders().add(o3);

               

                ses.save(c3);

               

                //System.out.println("Customer Id: " + c1.getCustId());

                //System.out.println("Patient Name: " + c1.getCustName());

               

               // Billing b1=new Billing(500,LocalDateTime.now(),1579);

               // Billing b2=new Billing(501,LocalDateTime.now(),123500);

               

                 b1.setCustomer(c1);

                 b1.setOrders(o1);

               

                b2.setCustomer(c2);

                b2.setOrders(o2);

               

                ses.save(b1);

                ses.save(b2);

               

                ses.beginTransaction().commit();

            */   

 

       }

 

}