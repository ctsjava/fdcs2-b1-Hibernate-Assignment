package com;

 

import java.util.ArrayList;

import java.util.List;

 

import javax.persistence.CascadeType;

import javax.persistence.Entity;

import javax.persistence.FetchType;

import javax.persistence.Id;

import javax.persistence.JoinColumn;

import javax.persistence.JoinTable;

import javax.persistence.ManyToMany;

import javax.persistence.Transient;

 

@Entity

public class Items {

      

       @Id

       private int ItemId;

       private String ItemName;

       private double price;

      

    

       @Transient

       @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)

          @JoinTable(name = "Order_Details", joinColumns = { @JoinColumn(name = "ItemId") },

          inverseJoinColumns = {@JoinColumn(name = "Orderid") })

      

          private List<Orders> orders = new ArrayList<Orders>();

      

       

       public Items() {

              // TODO Auto-generated constructor stub

       }

      

 

       public Items(int itemId, String itemName, double price) {

              super();

              ItemId = itemId;

              ItemName = itemName;

              this.price = price;

       }

      

       public List<Orders> getOrders() {

              return orders;

       }

       public void setOrders(List<Orders> orders) {

              this.orders = orders;

       }

       public int getItemId() {

              return ItemId;

       }

       public void setItemId(int itemId) {

              ItemId = itemId;

       }

       public String getItemName() {

              return ItemName;

       }

       public void setItemName(String itemName) {

              ItemName = itemName;

       }

       public double getPrice() {

              return price;

       }

       public void setPrice(double price) {

              this.price = price;

       }

      

 

}

 

 